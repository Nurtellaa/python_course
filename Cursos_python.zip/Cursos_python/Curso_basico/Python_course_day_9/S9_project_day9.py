import re
import os
import time
import datetime
import logging
from pathlib import Path
import zipfile
import send2trash
from prettytable import PrettyTable

# -------------------- Configuration --------------------

# Project path and zip/folder names
path = Path("/home/nur/Documentos/Cursos_python/Curso_basico/Python_course_day_9/")
zip_name = "Proyecto+Dia+9.zip"
folder_name = "Mi_Gran_Directorio"

# Regex pattern for serial numbers like Nbgw-12345
pattern = re.compile(r"N[a-z]{3}-\d{5}")

# Logging configuration
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# -------------------- Functions --------------------

def extract_and_delete_zip(path: Path, zip_name: str) -> None:
    """
    Extract a ZIP file and move it to trash after extraction.

    Args:
        path (Path): The directory where the ZIP file is located.
        zip_name (str): The name of the ZIP file to extract.
    """
    zip_path = path / zip_name
    if zip_path.exists():
        logging.info(f"Extracting zip: {zip_name}")
        with zipfile.ZipFile(zip_path, 'r') as zip_file:
            zip_file.extractall(path)
        send2trash.send2trash(str(zip_path))
        logging.info(f"Deleted zip file: {zip_path}")
    else:
        logging.warning("This zip file doesn't exist.")


def search_patterns(pattern: re.Pattern, path: Path, folder_name: str) -> tuple[list[str], list[str], int]:
    """
    Search for all serial numbers in files within a specific folder that match the given pattern.

    Args:
        pattern (Pattern): The compiled regex pattern to search.
        path (Path): The base path where the folder is located.
        folder_name (str): The name of the folder to search inside.

    Returns:
        tuple: (list of file paths, list of serial numbers, total number of serial numbers found)
    """
    folder_path = path / folder_name
    matched_files = []
    serial_numbers = []

    for folder, _, files in os.walk(folder_path):
        for file in files:
            file_path = Path(folder) / file
            try:
                text = file_path.read_text(encoding="utf-8", errors="ignore")
                result = pattern.findall(text)

                if result:
                    matched_files.append(str(file)) #saves the files name
                    serial_numbers.append(", ".join(result)) #saves the serial numbers
            except Exception as e:
                logging.warning(f"Error reading {file_path}: {e}")

    total_found = sum(s.count(",") + 1 for s in serial_numbers)
    return matched_files, serial_numbers, total_found


def record_execution_time(
    pattern: re.Pattern,
    path: Path,
    folder_name: str
) -> tuple[list[str], list[str], int, int]:
    """
    Measure how long it takes to search patterns in the given directory.

    Args:
        pattern (Pattern): The compiled regex pattern.
        path (Path): The base path to work on.
        folder_name (str): The name of the folder to search inside.

    Returns:
        tuple: (files, serial numbers, number of elements found, execution time in seconds)
    """
    start = time.time()
    files, serials, found_count = search_patterns(pattern, path, folder_name)
    end = time.time()
    execution_time = end - start
    return files, serials, found_count, execution_time


def get_current_date() -> datetime.date:
    """
    Get today's date.

    Returns:
        datetime.date: The current date.
    """
    return datetime.date.today()


def print_results(
    todays_date: datetime.date,
    files: list[str],
    serial_nums: list[str],
    found_num: int,
    searching_time: int
) -> None:
    """
    Display the results of the search in a formatted table.

    Args:
        todays_date (datetime.date): The date of execution.
        files (list): List of file paths where serials were found.
        serial_nums (list): List of found serial numbers.
        found_num (int): Total number of serials found.
        searching_time (int): Execution time of the search process.
    """
    print("\n-----------------------------------------")
    print(f"Date of search: {todays_date}\n")
    
    table = PrettyTable()
    table.field_names = ["FILES", "SERIAL NUMBER"]

    for f, s in zip(files, serial_nums):
        table.add_row([f, s])

    print(table)
    print(f"\nNumber of elements found: {found_num}")
    print(f"Searching time was: {searching_time} seconds")
    print("-----------------------------------------\n")


def main() -> None:
    """
    Main function to orchestrate the zip extraction, pattern search,
    and display of results.
    """
    extract_and_delete_zip(path, zip_name)
    files, serials, found, duration = record_execution_time(pattern, path, folder_name)
    today = get_current_date()
    print_results(today, files, serials, found, duration)


# -------------------- Entry Point --------------------

if __name__ == "__main__":
    main()
