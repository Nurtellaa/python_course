import os
import time

path = "/home/nur/Documentos/ENVIROMENT_PYTHON/curso_python"

for folder, subfolders, files in os.walk(path):
    print(f"In the folder: {folder}")
    print(f"The subfolder: ")

    for sub in subfolders:
        print(f"\t{sub}")

    print(f"The files: ")
    for fi in files:
        print(f"\t{fi}")

time.sleep(10)