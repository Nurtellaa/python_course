"""
    Console-based banking simulation program.
    Allows the user to create a client account and perform basic operations such as:
    - View account information
    - Deposit money
    - Withdraw money
    Includes basic error handling and user input validation.
"""

from os import system
import random
import time


class Person:
    """Represents a person with a name and surname."""
     # pylint: disable=too-few-public-methods
    def __init__(self, name: str, surname: str):
        self.name = name
        self.surname = surname


class Client(Person):
    """Represents a bank client, inheriting from Person.

    Attributes:
        account_number (str): The client's account number.
        balance (float): The client's current account balance.
    """

    def __init__(self, name: str, surname: str, account_number: str, balance: float):
        super().__init__(name, surname)
        self.account_number = account_number
        self.balance = round(balance, 2)

    def __str__(self) -> str:
        return (
            f"{self.name} {self.surname} is the owner of account {self.account_number} "
            f"with a balance of: {self.balance:.2f} €"
        )

    def deposit(self, amount: float):
        """Adds the specified amount to the balance."""
        self.balance += round(amount, 2)

    def subtract(self, amount: float):
        """Subtracts the specified amount from the balance."""
        self.balance -= round(amount, 2)


def create_client() -> Client:
    """Prompts the user to input data to create a new client."""
    while True:
        system('clear')
        try:
            name = input("Enter your name: ").strip()
            surname = input("Enter your surname: ").strip()

            if not name or not surname:
                raise ValueError("Name or surname cannot be empty.")

            balance = float(input("Enter the initial balance: "))
            account_number = "ES" + str(random.randint(1000000000, 9999999999))

            print("Client created successfully!")
            time.sleep(2)
            return Client(name, surname, account_number, balance)

        except ValueError as e:
            print(f"Input error: {e}")
            time.sleep(2)

        except (TypeError, IOError) as e:  # Add more specific ones if needed
            print(f"A specific error occurred: {e}")
            time.sleep(2)

        # If general catch is necessary:
        except Exception as e:  # pylint: disable=broad-exception-caught
            print(f"An unexpected error occurred: {e}")
            time.sleep(2)
            return None


def load_menu() -> int:
    """Displays the menu and returns the user's chosen option."""
    while True:
        system('clear')
        try:
            print("Choose an option from the menu")
            print("""
                1 - View client info
                2 - Deposit
                3 - Withdraw
                4 - Exit
            """)
            choice = int(input("Option: "))
            if 1 <= choice <= 4:
                return choice
            print("Invalid option. Choose between 1 and 4.")
            time.sleep(2)

        except ValueError:
            print("Invalid input. Please enter a number between 1 and 4.")
            time.sleep(2)


def print_client_info(client: Client):
    """Prints the client's information."""
    print(client)


def get_amount_input(action: str) -> float:
    """Asks the user to input an amount for deposit or withdrawal."""
    while True:
        try:
            return float(input(f"How much do you want to {action}? \n"))
        except ValueError:
            print("Invalid amount. Please enter a valid number.")


def deposit(client: Client, amount: float):
    """Deposits the specified amount to the client's account."""
    client.deposit(amount)
    print(f"{client.name} {client.surname} deposited {amount:.2f} €.\n"
          f"New balance: {client.balance:.2f} €")


def subtract(client: Client, amount: float):
    """Withdraws the specified amount from the client's account if possible."""
    if client.balance >= amount:
        client.subtract(amount)
        print(f"{client.name} {client.surname} withdrew {amount:.2f} €.\n"
              f"New balance: {client.balance:.2f} €")
    else:
        print("Insufficient funds.")


def start():
    """Starts the banking program."""
    system('clear')
    client = create_client()
    if not client:
        print("Failed to create client. Exiting.")
        return

    while True:
        choice = load_menu()

        if choice == 1:
            print_client_info(client)
            time.sleep(3)

        elif choice == 2:
            amount = get_amount_input("deposit")
            deposit(client, amount)
            time.sleep(2)

        elif choice == 3:
            amount = get_amount_input("withdraw")
            subtract(client, amount)
            time.sleep(2)

        elif choice == 4:
            print("Goodbye!")
            time.sleep(2)
            break


if __name__ == "__main__":
    start()
