"""
Adds two numbers.

Args:
    number1 (int): The first number.
    number2 (int): The second number.

Returns:
    int: The result of adding the two numbers.
"""

def add_numbers(number1: int, number2: int) -> int:
    """
    Adds two numbers.

    Args:
        number1 (int): The first number.
        number2 (int): The second number.

    Returns:
        int: The sum of the two numbers.
    """
    return number1 + number2

RESULT = add_numbers(5, 7)  # Variable name aligns with conventional naming
print(RESULT)
