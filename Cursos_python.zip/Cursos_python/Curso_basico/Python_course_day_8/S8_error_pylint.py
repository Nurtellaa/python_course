number1 = 500
print(Number1)