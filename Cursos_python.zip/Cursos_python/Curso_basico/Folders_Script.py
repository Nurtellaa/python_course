import os
from pathlib import Path

def create_folders_for_each_day(number:int) :
    counter = 0

    for n in range(0, number) :
        counter +=1
        exist = False
        while not exist :
            name = ("Python_course_day_" + str(counter))
            new_path = Path(name)

            if not os.path.exists(new_path) :
                Path.mkdir(new_path)
                exist = True
                print(f"The directory {name} was created, successfully")
            else :
                break

create_folders_for_each_day(16)