nombre = input("Ingresa el Nombre: ")
num_ventas = int(input("Ventas totales del mes: "))
comision = round(num_ventas * 13 / 100, 2)

print(f"hola {nombre}, tuscomisiones son de ${comision}")