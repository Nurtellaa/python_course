print("Hola")

a =2
b = a +2
c = b
c = 22
print(c)