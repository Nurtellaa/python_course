print("Línea 1\nLínea 2\nLínea 3")
print("A\tB\tC\nD\tE\tF\nG\tH\tI")
print("Barra Normal: /\nBarra Invertida: \\")