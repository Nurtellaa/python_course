print("Generador de nombres de cervezas")
print(input("¿Color favorito?") + input("¿Animalfavorito?"))