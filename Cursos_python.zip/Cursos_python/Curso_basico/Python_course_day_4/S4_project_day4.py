from random import randint

num_intentos = 0 
num_elegido = 0
num_random = randint(0, 101)
nombre = input("Escribe tu nombre: ")

print(f"{nombre}, Adivina el numero del 1al 100 en menos de 8 intentos")

while num_intentos < 8 :
    num_intentos += 1
    num_elegido = int(input("Escribe un numero del 1 al 100"))
    if(num_elegido > 0 and num_elegido < 101):
        if(num_elegido == num_random) :
            print("Felicidades has ganado")
            break
        elif(num_elegido > num_random) : 
            print("El numero es menor")
        elif(num_elegido < num_random) : 
            print("EL numero es mayor")

    else :
        print("El numero tiene que estar entre el 1 y el 100")
if num_intentos == 8 :
    print(f"Lo siento, se han agotado los intentos. El numero secreto era {num_random}")