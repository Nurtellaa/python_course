import time
import bs4
import requests

#url without page number
url_base = "https://books.toscrape.com/catalogue/page-{}.html"
high_rating_titles = []
#4-5 rating star books

start = time.time()
for page in range(1, 51):

    #create a soup for each page
    url_page = url_base.format(page)
    result = requests.get(url_page)
    soup = bs4.BeautifulSoup(result.text, "lxml")

    #select data from book
    books = soup.select(".product_pod")

    #
    for book in books:
        if len(book.select(".star-rating.Four")) != 0 or len(book.select(".star-rating.Five")):
            # save title
            book_title = book.select("a")[1]["title"]
            high_rating_titles.append(book_title)
end = time.time()
execution_time = end - start


for t in high_rating_titles:
    print(t)

print(f"It took {round(execution_time, 2)} seconds to execute the search")