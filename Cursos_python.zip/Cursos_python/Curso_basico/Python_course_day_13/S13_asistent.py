import speech_recognition as sr
import pywhatkit
import yfinance as yf
import pyjokes
import webbrowser
import datetime
import wikipedia
from gtts import gTTS
import playsound
import os


def speak(message):
    """
    Converts text to speech using gTTS.

    _summary_: Speaks the given message using a generated MP3 file.

    Args:
        message (str): 
            _type_: str
            _description_: The message to speak aloud.
    """
    try:
        tts = gTTS(text=message, lang='en')
        tts.save("temp.mp3")
        playsound.playsound("temp.mp3")
        os.remove("temp.mp3")
    except Exception as e:
        print("Error speaking:", e)


def transform_audio_to_text():
    """
    Listens to microphone input and returns recognized speech as text.

    _summary_: Captures voice input and processes it using Google's speech recognition API.

    Returns:
        str: 
            _type_: str
            _description_: The recognized voice command, or a default message if not understood.
    """
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        recognizer.pause_threshold = 0.8
        print("You can speak now...")

        audio = recognizer.listen(source)

        try:
            command = recognizer.recognize_google(audio, language="en-US")
            print("You said:", command)
            return command
        except sr.UnknownValueError:
            print("Oops, I didn't understand.")
            return "I'm still waiting"
        except sr.RequestError:
            print("Oops, service is down.")
            return "I'm still waiting"
        except Exception as e:
            print("Unexpected error:", e)
            return "I'm still waiting"


def tell_day():
    """
    Tells the current day of the week.

    _summary_: Uses the current date to determine the weekday and announces it.
    """
    today = datetime.date.today()
    day_number = today.weekday()

    days = {
        0: 'Monday',
        1: 'Tuesday',
        2: 'Wednesday',
        3: 'Thursday',
        4: 'Friday',
        5: 'Saturday',
        6: 'Sunday'
    }

    speak(f"Today is {days[day_number]}")


def tell_time():
    """
    Announces the current time.

    _summary_: Retrieves the current system time and vocalizes it.
    """
    now = datetime.datetime.now()
    time_message = f"It is {now.hour} hours, {now.minute} minutes and {now.second} seconds"
    print(time_message)
    speak(time_message)


def initial_greeting():
    """
    Greets the user based on the current time.

    _summary_: Provides an initial voice greeting with morning, afternoon, or evening.
    """
    now = datetime.datetime.now()
    if now.hour < 6 or now.hour > 20:
        moment = "Good evening"
    elif 6 <= now.hour < 13:
        moment = "Good morning"
    else:
        moment = "Good afternoon"

    speak(f"{moment}, I am Helena, your personal assistant. How can I help you?")


def handle_commands():
    """
    Main logic for handling spoken commands.

    _summary_: Listens for user commands and executes actions like opening websites,
    searching online, telling time, playing music, or fetching stock prices.

    Commands:
        - "open youtube"
        - "open browser"
        - "what day is it"
        - "what time is it"
        - "search on wikipedia"
        - "search the internet"
        - "play [song]"
        - "joke"
        - "stock price of [company]"
        - "goodbye" or "bye"
    """
    initial_greeting()
    running = True

    while running:
        command = transform_audio_to_text().lower()

        if 'open youtube' in command:
            speak('Sure, opening YouTube now.')
            webbrowser.open('https://www.youtube.com')
        elif 'open browser' in command:
            speak('Sure, opening your browser.')
            webbrowser.open('https://www.google.com')
        elif 'what day is it' in command:
            tell_day()
        elif 'what time is it' in command:
            tell_time()
        elif 'search on wikipedia' in command:
            speak('Searching on Wikipedia...')
            query = command.replace('search on wikipedia', '').strip()
            wikipedia.set_lang('en')
            try:
                result = wikipedia.summary(query, sentences=1)
                speak("According to Wikipedia:")
                speak(result)
            except:
                speak("Sorry, I couldn't find anything.")
        elif 'search the internet' in command:
            speak('Searching the internet...')
            query = command.replace('search the internet', '')
            pywhatkit.search(query)
            speak("Here is what I found.")
        elif 'play' in command:
            speak('Playing it now...')
            pywhatkit.playonyt(command)
        elif 'joke' in command:
            speak(pyjokes.get_joke(language="en"))
        elif 'stock price of' in command:
            try:
                stock_name = command.split('of')[-1].strip()
                portfolio = {
                    'apple': 'AAPL',
                    'amazon': 'AMZN',
                    'google': 'GOOGL'
                }
                stock_symbol = portfolio.get(stock_name.lower())
                if stock_symbol:
                    stock_data = yf.Ticker(stock_symbol)
                    current_price = stock_data.info['regularMarketPrice']
                    speak(f"The current price of {stock_name} is {current_price} dollars.")
                else:
                    speak("Sorry, I couldn't find that company.")
            except:
                speak("Something went wrong while fetching the stock data.")
        elif 'goodbye' in command or 'bye' in command:
            speak("Goodbye! Let me know if you need anything else.")
            running = False


# === Start the assistant ===
handle_commands()
