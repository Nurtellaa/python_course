from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):
    """
    Task model representing a user-specific to-do item.

    _summary_: Stores information about tasks assigned to users including title, description, status, and creation date.

    [extended_summary]: This model is part of a task management system where users can create, complete, and organize their personal tasks. The tasks are tied to authenticated Django users and ordered by their completion status for easy tracking.

    Attributes:
        user (User):
            _type_: ForeignKey to User
            _description_: The user to whom the task is assigned. If the user is deleted, their tasks will also be removed.

        title (str):
            _type_: CharField
            _description_: A short title summarizing the task.

        description (str):
            _type_: TextField
            _description_: An optional detailed description of the task.

        completed (bool):
            _type_: BooleanField
            _description_: Indicates whether the task has been completed.

        created (datetime):
            _type_: DateTimeField
            _description_: Timestamp of when the task was created.

    Returns:
        str:
            _type_: str
            _description_: Returns the title of the task when represented as a string.

    Meta:
        ordering (list):
            _type_: list
            _description_: Orders tasks by the 'completed' field by default.
    """

    user = models.ForeignKey(User,
                             on_delete=models.CASCADE,
                             null=True,
                             blank=True)
    title = models.CharField(max_length=200)
    description = models.TextField(null=True,
                                   blank=True)
    completed = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ["completed"]
