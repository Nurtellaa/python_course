from django.contrib.auth.views import LoginView
from django.views.generic.edit import FormView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from base.models import Task


class Login(LoginView):
    """
    Handles user login using Django's built-in LoginView.

    _summary_: Authenticates users and redirects authenticated users to the task list.

    Attributes:
        template_name (str): Path to the login template.
        redirect_authenticated_user (bool): Automatically redirect logged-in users.

    Returns:
        str: URL to the task list page after successful login.
    """
    template_name = "base/login.html"
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy("todo-list")


class Signup(FormView):
    """
    Handles user registration using Django's UserCreationForm.

    _summary_: Creates a new user account, logs them in, and redirects to the task list.

    Attributes:
        template_name (str): Path to the signup template.
        form_class (Form): The form used to create a new user.
        redirect_authenticated_user (bool): Prevents access if the user is already logged in.
        success_url (str): URL to redirect to upon successful signup.

    Methods:
        form_valid(form): Saves the user and logs them in.
        get(*args, **kwargs): Redirects authenticated users to the task list.
    """
    template_name = "base/signup.html"
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy("todo-list")

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super(Signup, self).form_valid(form)

    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect("todo-list")
        return super(Signup, self).get(*args, **kwargs)


class TodoList(LoginRequiredMixin, ListView):
    """
    Displays the list of tasks for the logged-in user.

    _summary_: Filters tasks by the current user and supports search functionality.

    Attributes:
        model (Model): Task model.
        context_object_name (str): The name of the context variable to use in the template.

    Methods:
        get_context_data(**kwargs): Filters tasks by user and search query.
    """
    model = Task
    context_object_name = "task"

    def get_context_data(self, **kwarg):
        context = super().get_context_data(**kwarg)
        context["task"] = context["task"].filter(user=self.request.user)

        searched_value = self.request.GET.get("search-area") or ""
        if searched_value:
            context["task"] = context["task"].filter(title__icontains=searched_value)
        context["searched_value"] = searched_value
        return context


class DetailTask(LoginRequiredMixin, DetailView):
    """
    Displays details of a specific task.

    _summary_: Shows the selected task's title, description, and status.

    Attributes:
        model (Model): Task model.
        context_object_name (str): The name of the context variable to use in the template.
        template_name (str): Path to the task detail template.
    """
    model = Task
    context_object_name = "task"
    template_name = "base/task.html"


class CreateTask(LoginRequiredMixin, CreateView):
    """
    Allows users to create a new task.

    _summary_: Presents a form for task creation and sets the user as the task owner.

    Attributes:
        model (Model): Task model.
        fields (list): Fields to include in the form.
        success_url (str): URL to redirect to after successful creation.
        template_name (str): Path to the task creation template.

    Methods:
        form_valid(form): Sets the current user before saving the task.
    """
    model = Task
    fields = ["title", "description", "completed"]
    success_url = reverse_lazy("todo-list")
    template_name = "base/create_task.html"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(CreateTask, self).form_valid(form)


class EditTask(LoginRequiredMixin, UpdateView):
    """
    Allows users to edit an existing task.

    _summary_: Lets the user modify any field of a task.

    Attributes:
        model (Model): Task model.
        fields (str): All model fields are editable.
        success_url (str): URL to redirect to after successful update.
        template_name (str): Path to the task update template.
    """
    model = Task
    fields = "__all__"
    success_url = reverse_lazy("todo-list")
    template_name = "base/create_task.html"


class DeleteTask(LoginRequiredMixin, DeleteView):
    """
    Allows users to delete an existing task.

    _summary_: Prompts confirmation before deleting a task.

    Attributes:
        model (Model): Task model.
        context_object_name (str): The name of the context variable to use in the template.
        success_url (str): URL to redirect to after successful deletion.
        template_name (str): Path to the delete confirmation template.
    """
    model = Task
    context_object_name = "task"
    success_url = reverse_lazy("todo-list")
    template_name = "base/task_confirm_delete.html"


@csrf_exempt
def toggle_task_completed(request):
    """
    Toggles the completed status of a task via POST request.

    _summary_: Receives task ID and completion status, updates the task, and returns JSON response.

    Args:
        request (HttpRequest): The incoming request containing POST data.

    Returns:
        JsonResponse: Contains success status or error message.

    Exceptions:
        Task.DoesNotExist: Task with the given ID was not found.
    """
    if request.method == "POST":
        task_id = request.POST.get("task_id")
        completed = request.POST.get("completed") == "true"

        try:
            task = Task.objects.get(id=task_id)
            task.completed = completed
            task.save()
            return JsonResponse({"success": True})
        except Task.DoesNotExist:
            return JsonResponse({"success": False, "error": "Task not found"})
    return JsonResponse({"success": False, "error": "Invalid method"})
