// Highlight input fields when focused
document.addEventListener('DOMContentLoaded', function () {
    const inputs = document.querySelectorAll('input[type="text"], input[type="password"]');
    inputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.style.borderColor = '#4a90e2';
        });
        input.addEventListener('blur', () => {
            input.style.borderColor = '#ccc';
        });
    });

    // Confirm delete
    const deleteForms = document.querySelectorAll('form.delete-form');
    deleteForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            const confirmed = confirm('Are you sure you want to delete this task?');
            if (!confirmed) e.preventDefault();
        });
    });
});

<script>
document.querySelectorAll('.task-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        const taskId = this.dataset.taskId;
        const completed = this.checked;

        fetch("{% url 'toggle-task' %}", {
            method: "POST",
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRFToken': '{{ csrf_token }}'
            },
            body: `task_id=${taskId}&completed=${completed}`
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                alert("Error updating task");
            }
        });
    });
});
</script>
