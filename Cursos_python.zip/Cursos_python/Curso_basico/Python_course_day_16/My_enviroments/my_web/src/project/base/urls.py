from django.urls import path
from .views import TodoList, DetailTask, CreateTask, EditTask, DeleteTask, Login, Signup, toggle_task_completed
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path("login/", Login.as_view(), name="login"),
    path("logout/", LogoutView.as_view(next_page="login"), name="logout"),
    path("signup/", Signup.as_view(), name="signup"),
    path("", TodoList.as_view(), name="todo-list"),
    path("task/<int:pk>", DetailTask.as_view(), name="task"),
    path('toggle-task/', toggle_task_completed, name='toggle-task'),
    path("create-task", CreateTask.as_view(), name="create-task"),
    path("edit-task/<int:pk>", EditTask.as_view(), name="edit-task"),
    path("delete-task/<int:pk>", DeleteTask.as_view(), name="delete-task")
]
