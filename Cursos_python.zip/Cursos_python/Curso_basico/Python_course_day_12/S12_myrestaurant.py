from tkinter import *
import random
import datetime
from tkinter import filedialog, messagebox

operator = ""
prices_food = [12.32, 3.65, 2.31, 3.22, 1.22, 1.99, 2.05, 2.65]
prices_drinks = [0.25, 0.99, 1.21, 1.54, 1.08, 1.10, 2.00, 1.58]
prices_desserts = [1.54, 1.68, 1.32, 1.97, 2.55, 2.14, 1.94, 1.74]

def click_button(num):
    """
    Appends the clicked number to the calculator display.

    _summary_: Builds a string expression from button clicks for later evaluation.

    Args:
        num (str): 
            _type_: str
            _description_: The number or operator clicked by the user.
    """
    global operator
    operator += num
    calc_visor.delete(0, END)
    calc_visor.insert(END, operator)


def reset():
    """
    Resets the interface and clears all values.

    _summary_: Clears the ticket display, disables all input fields,
    resets variables, and prepares the app for a new order.
    """
    text_ticket.delete(0.1, END)
    for text in text_food:
        text.set("0")
    for text in text_drinks:
        text.set("0")
    for text in text_desserts:
        text.set("0")
    for square in squares_food:
        square.config(state=DISABLED)
    for square in squares_drinks:
        square.config(state=DISABLED)
    for square in squares_desserts:
        square.config(state=DISABLED)
    for v in variables_food:
        v.set(0)
    for v in variables_drinks:
        v.set(0)
    for v in variables_desserts:
        v.set(0)
    var_food_price.set("")
    var_drinks_price.set("")
    var_desserts_price.set("")
    var_subtotal_price.set("")
    var_tax_price.set("")
    var_total_price.set("")


def delete():
    """
    Clears the calculator input.

    _summary_: Resets the calculator display and internal operator string.
    """
    global operator
    operator = ""
    calc_visor.delete(0, END)


def get_result():
    """
    Evaluates the expression in the calculator.

    _summary_: Calculates and displays the result of the current operation.

    Returns:
        str: 
            _type_: str
            _description_: The result of the mathematical expression.
    """
    global operator
    result = str(eval(operator))
    calc_visor.delete(0, END)
    calc_visor.insert(0, result)
    operator = ""


def save():
    """
    Saves the content of the ticket to a text file.

    _summary_: Opens a file dialog, writes ticket information, and shows confirmation.
    """
    ticket_info = text_ticket.get(1.0, END)
    file = filedialog.asksaveasfile(mode="w", defaultextension=".txt")
    file.write(ticket_info)
    messagebox.showinfo("Information", "Your ticket has been saved")


def ticket():
    """
    Generates a ticket with selected items and prices.

    _summary_: Populates the ticket area with items, prices, totals, and timestamps.
    """
    text_ticket.delete(1.0, END)
    num_ticket = f"N# - {random.randint(1000, 9999)}"
    date = datetime.datetime.now()
    date_ticket = f"{date.day}/{date.month}/{date.year} - {date.hour}:{date.minute}"
    text_ticket.insert(END, f"Data: \t{num_ticket}\t\t{date_ticket}\n")
    text_ticket.insert(END, f"*" * 47, "\n")
    text_ticket.insert(END, "\n Items\t\tCant.\tPrice\n")
    text_ticket.insert(END, f"-" * 54, "\n")

    x = 0
    for food in text_food:
        if food.get() != "0":
            text_ticket.insert(END, f"\n{list_foods[x]}\t\t{food.get()}\t"
                                    f" {int(food.get()) * prices_food[x]} € \n")
        x += 1
    x = 0
    for drinks in text_drinks:
        if drinks.get() != "0":
            text_ticket.insert(END, f"\n{list_drinks[x]}\t\t{drinks.get()}\t"
                                    f" {int(drinks.get()) * prices_drinks[x]} € \n")
        x += 1
    x = 0
    for desserts in text_desserts:
        if desserts.get() != "0":
            text_ticket.insert(END, f"\n{list_desserts[x]}\t\t{desserts.get()}\t"
                                    f" {int(desserts.get()) * prices_desserts[x]} € \n")
        x += 1

    total()

    text_ticket.insert(END, f"-" * 54, "\n")
    text_ticket.insert(END, f"\nSubtotal of food: \t\t\t{var_food_price.get()}\n")
    text_ticket.insert(END, f"Subtotal of drinks: \t\t\t{var_drinks_price.get()}\n")
    text_ticket.insert(END, f"Subtotal of desserts: \t\t\t{var_desserts_price.get()}\n")
    text_ticket.insert(END, f"-" * 54, "\n")
    text_ticket.insert(END, f"\nSubtotal: \t\t\t{var_subtotal_price.get()}\n")
    text_ticket.insert(END, f"Tax: \t\t\t{var_tax_price.get()}\n")
    text_ticket.insert(END, f"Total: \t\t\t{var_total_price.get()}\n")
    text_ticket.insert(END, f"-" * 54, "\n")
    text_ticket.insert(END, "\nSee you next time <3")


def check_checkers():
    """
    Enables/disables input fields based on checkbox status.

    _summary_: Activates entry fields when checkbox is selected and resets others.
    """
    x = 0
    for s in squares_food:
        if variables_food[x].get() == 1:
            s.config(state=NORMAL)
            if s.get == 0:
                s.delete(0, END)
            s.focus()
        else:
            s.config(state=DISABLED)
            text_food[x].set("0")
        x += 1

    x = 0
    for s in squares_drinks:
        if variables_drinks[x].get() == 1:
            s.config(state=NORMAL)
            if s.get == 0:
                s.delete(0, END)
            s.focus()
        else:
            s.config(state=DISABLED)
            text_drinks[x].set("0")
        x += 1

    x = 0
    for s in squares_desserts:
        if variables_desserts[x].get() == 1:
            s.config(state=NORMAL)
            if s.get == 0:
                s.delete(0, END)
            s.focus()
        else:
            s.config(state=DISABLED)
            text_desserts[x].set("0")
        x += 1


def total():
    """
    Calculates subtotals, tax, and total.

    _summary_: Computes the prices based on selected quantities and updates display variables.

    Returns:
        float: 
            _type_: float
            _description_: The final total price including tax.
    """
    subtotal_food = 0
    p = 0
    for quantity in text_food:
        subtotal_food += (float(quantity.get()) * prices_food[p])
        p += 1

    subtotal_drinks = 0
    p = 0
    for quantity in text_drinks:
        subtotal_drinks += (float(quantity.get()) * prices_drinks[p])
        p += 1

    subtotal_desserts = 0
    p = 0
    for quantity in text_desserts:
        subtotal_desserts += (float(quantity.get()) * prices_desserts[p])
        p += 1

    subtotal = subtotal_food + subtotal_drinks + subtotal_desserts
    tax = subtotal * 0.21
    total_price = subtotal + tax

    var_food_price.set(f"{round(subtotal_food, 2)} €")
    var_drinks_price.set(f"{round(subtotal_drinks, 2)} €")
    var_desserts_price.set(f"{round(subtotal_desserts, 2)} €")
    var_subtotal_price.set(f"{round(subtotal, 2)} €")
    var_tax_price.set(f"{round(tax, 2)} €")
    var_total_price.set(f"{round(total_price, 2)} €")

    return total_price


application = Tk()

#screen
application.geometry("1020x630+0+0")
#prevent user for max the screen
application.resizable(0,0)
# title for the scree
application.title("Facturation system for my restaurant")
#screen background color
application.config(bg="burlywood")
#upper panel
upper_panel = Frame(application, bd=1, relief=FLAT)
upper_panel.pack(side=TOP)

#title tag
title_tag = Label(upper_panel,text="Facturation system", fg="azure4",
                  font=("Dosis", 58), bg="burlywood", width=25)
title_tag.grid(row=0, column=0)

#left panel
left_panel = Frame(application, bd=1, relief=FLAT)
left_panel.pack(side=LEFT)

#cost panel
cost_panel = Frame(left_panel, bd=1, relief=FLAT)
cost_panel.pack(side=BOTTOM)

#food panel
food_panel = LabelFrame(left_panel, 
                        text="Food", 
                        font=("Dosis", 14, "bold"),
                        bd=1, 
                        relief=FLAT, 
                        fg="azure4")
food_panel.pack(side=LEFT)
#drinks panel
drinks_panel = LabelFrame(left_panel, 
                        text="Drinks", 
                        font=("Dosis", 14, "bold"),
                        bd=1, 
                        relief=FLAT, 
                        fg="azure4")
drinks_panel.pack(side=LEFT)
#dessert panel
desserts_panel = LabelFrame(left_panel, 
                            text="Desserts", 
                            font=("Dosis", 14, "bold"),
                            bd=1, 
                            relief=FLAT, 
                            fg="azure4")
desserts_panel.pack(side=LEFT)

#right panel
right_panel = Frame(application, bd=1, relief=FLAT)
right_panel.pack(side=RIGHT)

#calculator panel
calculator_panel = Frame (right_panel, bd=1, relief=FLAT, bg="burlywood")
calculator_panel.pack()
#ticket panel
ticket_panel = Frame (right_panel, bd=1, relief=FLAT, bg="burlywood")
ticket_panel.pack()
#buttons panel
buttons_panel = Frame (right_panel, bd=1, relief=FLAT, bg="burlywood")
buttons_panel.pack()

#lists
list_foods = ["Pizza", "Fried", "Rice", "Potato", "Tomato soup", "Food1", "Food2", "Food3"]
list_drinks = ["Water", "Beer", "wine", "Soda", "Juice", "drin1", "drink2", "drink3"]
list_desserts = ["icecream","fruits","chocolate", "brownie", "flan", "mousse", "cake", "pie"]

#food items
variables_food = []
squares_food = []
text_food = []
counter = 0
for food in list_foods:
    variables_food.append("")
    variables_food[counter] = IntVar()
    food = Checkbutton(food_panel, 
                       text=food.title(), 
                       font=("Dosis", 14, "bold"), 
                       onvalue=1, 
                       offvalue=0, 
                       variable=variables_food[counter], 
                       command=check_checkers)
    food.grid(row=counter, column=0, sticky=W)

    #entry squares
    squares_food.append("")
    text_food.append("")
    text_food[counter] = StringVar()
    text_food[counter].set("0")
    squares_food[counter] = Entry(food_panel,
                                  font=("Dosis", 18, "bold"),
                                  bd=1,
                                  width=4,
                                  state=DISABLED,
                                  textvariable=text_food[counter])
    
    squares_food[counter].grid(row=counter, column=1)

    counter += 1

#drinks items
variables_drinks = []
squares_drinks = []
text_drinks = []
counter = 0
for drinks in list_drinks:
    variables_drinks.append("")
    variables_drinks[counter] = IntVar()
    drinks = Checkbutton(drinks_panel, 
                       text=drinks.title(), 
                       font=("Dosis", 14, "bold"), 
                       onvalue=1, 
                       offvalue=0, 
                       variable=variables_drinks[counter], 
                       command=check_checkers)
    drinks.grid(row=counter, column=0, sticky=W)

    #entry squares
    squares_drinks.append("")
    text_drinks.append("")
    text_drinks[counter] = StringVar()
    text_drinks[counter].set("0")
    squares_drinks[counter] = Entry(drinks_panel,
                                  font=("Dosis", 18, "bold"),
                                  bd=1,
                                  width=4,
                                  state=DISABLED,
                                  textvariable=text_drinks[counter])
    
    squares_drinks[counter].grid(row=counter, column=1)

    counter += 1

#desserts items
variables_desserts = []
squares_desserts = []
text_desserts = []
counter = 0
for desserts in list_desserts:
    variables_desserts.append("")
    variables_desserts[counter] = IntVar()
    desserts = Checkbutton(desserts_panel, 
                       text=desserts.title(), 
                       font=("Dosis", 14, "bold"), 
                       onvalue=1, 
                       offvalue=0, 
                       variable=variables_desserts[counter], 
                       command=check_checkers)
    desserts.grid(row=counter, column=0, sticky=W)

    #entry squares
    squares_desserts.append("")
    text_desserts.append("")
    text_desserts[counter] = StringVar()
    text_desserts[counter].set("0")

    squares_desserts[counter] = Entry(desserts_panel,
                                  font=("Dosis", 18, "bold"),
                                  bd=1,
                                  width=4,
                                  state=DISABLED,
                                  textvariable=text_desserts[counter])
    
    squares_desserts[counter].grid(row=counter, column=1)

    counter += 1

#tag price and entry fields
var_food_price  = StringVar()
food_price_tag = Label(cost_panel,
                       text="Food Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
food_price_tag.grid(row=0, column=0)
text_food_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_food_price)
text_food_price.grid(row=0, column=1)

var_drinks_price  = StringVar()
drinks_price_tag = Label(cost_panel,
                       text="drinks Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
drinks_price_tag.grid(row=1, column=0)
text_drinks_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_drinks_price)
text_drinks_price.grid(row=1, column=1)

var_desserts_price  = StringVar()
desserts_price_tag = Label(cost_panel,
                       text="desserts Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
desserts_price_tag.grid(row=2, column=0)
text_desserts_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_desserts_price)
text_desserts_price.grid(row=2, column=1)

#subtotal and taxes
var_subtotal_price  = StringVar()
subtotal_price_tag = Label(cost_panel,
                       text="subtotal Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
subtotal_price_tag.grid(row=0, column=2)
text_subtotal_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_subtotal_price)
text_subtotal_price.grid(row=0, column=3)

var_tax_price  = StringVar()
tax_price_tag = Label(cost_panel,
                       text="tax Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
tax_price_tag.grid(row=1, column=2)
text_tax_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_tax_price)
text_tax_price.grid(row=1, column=3)

var_total_price  = StringVar()
total_price_tag = Label(cost_panel,
                       text="total Price",
                       font=("Dosis", 12, "bold"),
                       bg="azure4",
                       fg="white")
total_price_tag.grid(row=2, column=2)
text_total_price = Entry(cost_panel,
                        font=("Dosis", 12, "bold"),
                        bd=1,
                        width=10,
                        state="readonly",
                        textvariable=var_total_price)
text_total_price.grid(row=2, column=3)

# buttons
buttons = ["total", "ticket", "Save", "Reset"]
buttons_created= []
columns = 0
for button in buttons:
    button = Button(buttons_panel,
                  text=button.title(),
                  font=("Dosis", 11, "bold"),
                  fg="white",
                  bg = "azure4",
                  bd=1, 
                  width=6)
    
    buttons_created.append(button)
    button.grid(row=0, column=columns)
    columns += 1

buttons_created[0].config(command=total)
buttons_created[1].config(command=ticket)
buttons_created[2].config(command=save)
buttons_created[3].config(command=reset)

#ticket area
text_ticket = StringVar()
text_ticket = Text(ticket_panel,
                   font=("Dosis", 10, "bold"),
                   bd=1,
                   width=42,
                   height=10)
text_ticket.grid(row=0, column=0)

#calculator
calc_visor = Entry(calculator_panel,
                   font=("Dosis", 10, "bold"),
                   width=32,
                   bd=1)
calc_visor.grid(row=0, column=0, columnspan=4)

calc_buttons = ["7","8","9","+","4","5","6","-","1","2","3","x","=","Delete","0","/",]
saved_buttons = []
calc_row = 1
calc_column = 0

for button in calc_buttons:
    button = Button(calculator_panel,
                    text=button.title(),
                    font=("Dosis", 10, "bold"),
                    fg="black",
                    bg="azure",
                    bd=1,
                    width=6)
    saved_buttons.append(button)
    button.grid(row= calc_row, column= calc_column)

    if calc_column == 3:
        calc_row +=1

    calc_column +=1

    if calc_column == 4:
        calc_column = 0

saved_buttons[0].config(command=lambda : click_button("7"))
saved_buttons[1].config(command=lambda : click_button("8"))
saved_buttons[2].config(command=lambda : click_button("9"))
saved_buttons[3].config(command=lambda : click_button("+"))
saved_buttons[4].config(command=lambda : click_button("4"))
saved_buttons[5].config(command=lambda : click_button("5"))
saved_buttons[6].config(command=lambda : click_button("6"))
saved_buttons[7].config(command=lambda : click_button("-"))
saved_buttons[8].config(command=lambda : click_button("1"))
saved_buttons[9].config(command=lambda : click_button("2"))
saved_buttons[10].config(command=lambda : click_button("3"))
saved_buttons[11].config(command=lambda : click_button("x"))
saved_buttons[12].config(command=get_result)
saved_buttons[13].config(command=delete)
saved_buttons[14].config(command=lambda : click_button("0"))
saved_buttons[15].config(command=lambda : click_button("/"))

#to prevent the screen from closing
application.mainloop()