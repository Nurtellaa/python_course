import datetime
import cv2
import face_recognition as fr
import os
import numpy
from datetime import datetime

# === Load Employee Images ===
# Create "database" for employees
path = "Python_course_day_14/Employees/"
my_images = []
employees_names = []

list_employees = os.listdir(path)

for name in list_employees:
    current_image = cv2.imread(f"{path}{name}")
    if current_image is not None:
        my_images.append(current_image)
        employees_names.append(os.path.splitext(name)[0])
    else:
        print(f"Image {name} could not be loaded.")

print("Employees loaded:", employees_names)


def encode(images):
    """
    Encodes face images into facial feature vectors.

    _summary_: Converts each image into a numerical representation (encoding)
    suitable for face comparison using the face_recognition library.

    Args:
        images (list): 
            _type_: list of np.ndarray
            _description_: List of images (as NumPy arrays) to encode.

    Returns:
        list: 
            _type_: list of numpy.ndarray
            _description_: List of 128-dimensional face encodings.
    """
    list_encode = []
    for image in images:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        encodings = fr.face_encodings(image)
        if encodings:
            list_encode.append(encodings[0])
        else:
            print("No face found in one image.")
    return list_encode


list_employees_encoded = encode(my_images)


def register_entry(person):
    """
    Registers the time entry of a recognized person into a CSV file.

    _summary_: Prevents duplicate entries and logs the name and timestamp of newly seen individuals.

    Args:
        person (str): 
            _type_: str
            _description_: Name of the employee to log.
    """
    file_path = "Python_course_day_14/employees_entrys.csv"
    
    with open(file_path, "r+") as f:
        data_list = f.readlines()
        registry_names = [line.split(",")[0].strip() for line in data_list]

        if person not in registry_names:
            now = datetime.now()
            str_now = now.strftime("%H:%M:%S")
            f.write(f"\n{person}, {str_now}")


# === Camera Capture and Face Recognition ===
# Try multiple camera indexes to find a working one
for cam_index in range(3):
    capture = cv2.VideoCapture(cam_index)
    success, image = capture.read()
    if success:
        print(f"Camera {cam_index} is working.")
        break
    capture.release()

if not success:
    print("No working camera found.")
else:
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    face_locations = fr.face_locations(image_rgb)
    captured_face_encoded = fr.face_encodings(image_rgb, face_locations)

    for faceenco, faceloc in zip(captured_face_encoded, face_locations):
        coincidence = fr.compare_faces(list_employees_encoded, faceenco, 0.4)
        distance = fr.face_distance(list_employees_encoded, faceenco)

        print("Face match distances:", distance)
        if True in coincidence:
            match_index = coincidence.index(True)
            print(f"Welcome, {employees_names[match_index]}!")
            cv2.putText(
                image,
                f"{round(min(distance), 2)} Welcome, {employees_names[match_index]}",
                (50, 50),
                cv2.FONT_HERSHEY_COMPLEX,
                1,
                (0, 255, 0),
                2
            )
            register_entry(employees_names[match_index])
        else:
            print("Face not recognized.")
            cv2.putText(
                image,
                f"{distance} {distance.round(2)} \n Face not recognized.",
                (50, 50),
                cv2.FONT_HERSHEY_COMPLEX,
                1,
                (0, 255, 0),
                2
            )

    # Draw rectangles around detected faces
    for top, right, bottom, left in face_locations:
        cv2.rectangle(image, (left, top), (right, bottom), (0, 255, 0), 2)

    cv2.imshow("Face Recognition", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
