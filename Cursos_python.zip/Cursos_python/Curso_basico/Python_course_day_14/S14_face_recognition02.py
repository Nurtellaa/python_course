import cv2
import face_recognition as fr

def load_and_process_image(path):
    """Load an image and convert it to RGB."""
    image = fr.load_image_file(path)
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

def detect_face(image):
    """Detect the first face and return its location and encoding."""
    locations = fr.face_locations(image)
    encodings = fr.face_encodings(image)
    if locations and encodings:
        return locations[0], encodings[0]
    return None, None

def draw_face_box(image, location, color=(0, 255, 0), thickness=2):
    """Draw a rectangle around the face."""
    top, right, bottom, left = location
    cv2.rectangle(image, (left, top), (right, bottom), color, thickness)

# Load and process images
photo_control = load_and_process_image("Python_course_day_14/Photo_01.jpg")
photo_test = load_and_process_image("Python_course_day_14/Photo_06.jpg")

# Detect faces
face_location_A, encoding_A = detect_face(photo_control)
face_location_B, encoding_B = detect_face(photo_test)

if face_location_A and face_location_B:
    # Draw rectangles
    draw_face_box(photo_control, face_location_A)
    draw_face_box(photo_test, face_location_B)

    # Compare faces
    result = fr.compare_faces([encoding_A], encoding_B)[0]
    distance = fr.face_distance([encoding_A], encoding_B)[0]

    print(f"Match: {result}")
    print(f"Distance: {distance:.2f}")

    # Show result on image
    cv2.putText(photo_test,
                f"{result} {distance:.2f}",
                (50, 50),
                cv2.FONT_HERSHEY_COMPLEX,
                1,
                (0, 255, 0),
                2)

    # Display images
    cv2.imshow("Photo Control", photo_control)
    cv2.imshow("Photo Test", photo_test)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
else:
    print("No face detected in one or both images.")
