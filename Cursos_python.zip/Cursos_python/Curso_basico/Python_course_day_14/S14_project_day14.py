import cv2
import face_recognition as fr
import os

#create "database" for employees 
path = "Python_course_day_14/Employees/" 
my_images =[]
employees_names = []
list_employees = os.listdir(path)

for name in list_employees:
    current_image = cv2.imread(f"{path} {name}")
    my_images.append(current_image)
    employees_names.append(os.path.splitext(name)[0])

print(employees_names)

# encode images
def encode(images):
    #new list
    list_encode = []

    #move all images
    for image in images:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        #encode
        encoded = fr.face_encodings(image)[0]

        #add to the list
        list_encode.append(encoded)
    # return encoded list
    return list_encode

list_employees_encoded = encode(my_images)

#take an image from webcam
capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)

#read image of the cam
success, image = capture.read()

if not success:
    print("It could't take the capture")
else:
    # recognize the face of the capture
    capture_face = fr.face_locations(image)
    #encode face
    captured_face_encoded = fr.face_encodings(image,capture_face)
    #search for coincidences
    for faceenco, faceloc in zip(captured_face_encoded, capture_face):
        coincidence = fr.compare_faces(list_employees_encoded, faceenco)
        distance = fr.face_distance(list_employees_encoded, faceenco)

        print(distance)