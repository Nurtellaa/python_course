import cv2
import face_recognition as fr

# charge images
photo_control = fr.load_image_file("Python_course_day_14/Photo_01.jpg")
photo_test = fr.load_image_file("Python_course_day_14/Photo_02.jpg")

#Convert images to RGB
photo_control = cv2.cvtColor(photo_control,cv2.COLOR_BGR2RGB)
photo_test = cv2.cvtColor(photo_test,cv2.COLOR_BGR2RGB)

#Localize face control
face_position_A = fr.face_locations(photo_control)[0]
face_encoding_A = fr.face_encodings(photo_control)[0]

#Localize face test
face_position_B = fr.face_locations(photo_test)[0]
face_encoding_B = fr.face_encodings(photo_test)[0]

# show rectangles
cv2.rectangle(photo_control,
      (face_position_A[3], face_position_A[0]),
      (face_position_A[1],face_position_A[2]),
      (0,255,0),
      2)
cv2.rectangle(photo_test,
      (face_position_B[3], face_position_B[0]),
      (face_position_B[1],face_position_B[2]),
      (0,255,0),
      2)

#Compare both images
result = fr.compare_faces([face_encoding_A], face_encoding_B)
print(result)

#Show images
cv2.imshow("Photo control", photo_control)
cv2.imshow("Photo test", photo_test)

#mesure the face distance
distance = fr.face_distance([face_encoding_A], face_encoding_B)
print(distance)

# Show results in images
cv2.putText(photo_test,
            f"{result} {distance.round(2)}",
            (50,50),
            cv2.FONT_HERSHEY_COMPLEX,
            1,
            (0, 255, 0),
            2)


#Keep waiting
cv2.waitKey(0)