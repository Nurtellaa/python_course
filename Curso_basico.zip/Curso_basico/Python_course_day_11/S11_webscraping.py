import bs4
import requests

result = requests.get("https://www.escueladirecta.com/l/products")

#print(type(result))
#print(result.text) #returns a string 

soup = bs4.BeautifulSoup(result.text, "lxml") # Parses the result into a xml using bs4

#print(soup)
#print(soup.select("title"))
#print(soup.select("title")[0]) 
#print(len(soup.select("p")))

web_images = soup.select('img')[2]['src']
print(web_images)
image_one = requests.get(web_images)

f = open("my_image.svg", "wb")
f.write(image_one.content)
f.close