import tkinter as tk
from tkinter import filedialog, messagebox
import random
import datetime

class RestaurantBillingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Facturation system for my restaurant")
        self.root.geometry("1020x630+0+0")
        self.root.resizable(0, 0)
        self.root.config(bg="burlywood")

        self.operator = ""
        self.tax_rate = 0.21

        self.food_prices = [12.32, 3.65, 2.31, 3.22, 1.22, 1.99, 2.05, 2.65]
        self.drink_prices = [0.25, 0.99, 1.21, 1.54, 1.08, 1.10, 2.00, 1.58]
        self.dessert_prices = [1.54, 1.68, 1.32, 1.97, 2.55, 2.14, 1.94, 1.74]

        self.food_items = ["Pizza", "Fried", "Rice", "Potato", "Tomato soup", "Food1", "Food2", "Food3"]
        self.drink_items = ["Water", "Beer", "Wine", "Soda", "Juice", "Drink1", "Drink2", "Drink3"]
        self.dessert_items = ["Ice Cream", "Fruits", "Chocolate", "Brownie", "Flan", "Mousse", "Cake", "Pie"]

        self.setup_variables()
        self.build_ui()

    def setup_variables(self):
        self.var_food_price = tk.StringVar()
        self.var_drinks_price = tk.StringVar()
        self.var_desserts_price = tk.StringVar()
        self.var_subtotal_price = tk.StringVar()
        self.var_tax_price = tk.StringVar()
        self.var_total_price = tk.StringVar()

    def build_ui(self):
        self.build_panels()
        self.build_food_panel()
        self.build_drinks_panel()
        self.build_desserts_panel()
        self.build_cost_panel()
        self.build_calculator()
        self.build_ticket_area()
        self.build_buttons()

    def build_panels(self):
        self.upper_panel = tk.Frame(self.root, bd=1, relief=tk.FLAT)
        self.upper_panel.pack(side=tk.TOP)

        self.title_tag = tk.Label(self.upper_panel, text="Facturation system", fg="azure4",
                                  font=("Dosis", 58), bg="burlywood", width=25)
        self.title_tag.grid(row=0, column=0)

        self.left_panel = tk.Frame(self.root, bd=1, relief=tk.FLAT)
        self.left_panel.pack(side=tk.LEFT)

        self.cost_panel = tk.Frame(self.left_panel, bd=1, relief=tk.FLAT)
        self.cost_panel.pack(side=tk.BOTTOM)

        self.food_panel = tk.LabelFrame(self.left_panel, text="Food", font=("Dosis", 14, "bold"),
                                        bd=1, relief=tk.FLAT, fg="azure4")
        self.food_panel.pack(side=tk.LEFT)

        self.drinks_panel = tk.LabelFrame(self.left_panel, text="Drinks", font=("Dosis", 14, "bold"),
                                          bd=1, relief=tk.FLAT, fg="azure4")
        self.drinks_panel.pack(side=tk.LEFT)

        self.desserts_panel = tk.LabelFrame(self.left_panel, text="Desserts", font=("Dosis", 14, "bold"),
                                            bd=1, relief=tk.FLAT, fg="azure4")
        self.desserts_panel.pack(side=tk.LEFT)

        self.right_panel = tk.Frame(self.root, bd=1, relief=tk.FLAT)
        self.right_panel.pack(side=tk.RIGHT)

        self.calculator_panel = tk.Frame(self.right_panel, bd=1, relief=tk.FLAT, bg="burlywood")
        self.calculator_panel.pack()

        self.ticket_panel = tk.Frame(self.right_panel, bd=1, relief=tk.FLAT, bg="burlywood")
        self.ticket_panel.pack()

        self.buttons_panel = tk.Frame(self.right_panel, bd=1, relief=tk.FLAT, bg="burlywood")
        self.buttons_panel.pack()

    def build_food_panel(self):
        self.food_vars = []
        self.food_entries = []
        for i, item in enumerate(self.food_items):
            var = tk.IntVar()
            entry_var = tk.StringVar(value="0")
            chk = tk.Checkbutton(self.food_panel, text=item, font=("Dosis", 14, "bold"),
                                 onvalue=1, offvalue=0, variable=var)
            chk.grid(row=i, column=0, sticky="w")

            entry = tk.Entry(self.food_panel, font=("Dosis", 18, "bold"), bd=1, width=4,
                             state=tk.DISABLED, textvariable=entry_var)
            entry.grid(row=i, column=1)

            self.food_vars.append(var)
            self.food_entries.append(entry)

    def build_drinks_panel(self):
        self.drink_vars = []
        self.drink_entries = []
        for i, item in enumerate(self.drink_items):
            var = tk.IntVar()
            entry_var = tk.StringVar(value="0")
            chk = tk.Checkbutton(self.drinks_panel, text=item, font=("Dosis", 14, "bold"),
                                 onvalue=1, offvalue=0, variable=var)
            chk.grid(row=i, column=0, sticky="w")

            entry = tk.Entry(self.drinks_panel, font=("Dosis", 18, "bold"), bd=1, width=4,
                             state=tk.DISABLED, textvariable=entry_var)
            entry.grid(row=i, column=1)

            self.drink_vars.append(var)
            self.drink_entries.append(entry)

    def build_desserts_panel(self):
        self.dessert_vars = []
        self.dessert_entries = []
        for i, item in enumerate(self.dessert_items):
            var = tk.IntVar()
            entry_var = tk.StringVar(value="0")
            chk = tk.Checkbutton(self.desserts_panel, text=item, font=("Dosis", 14, "bold"),
                                 onvalue=1, offvalue=0, variable=var)
            chk.grid(row=i, column=0, sticky="w")

            entry = tk.Entry(self.desserts_panel, font=("Dosis", 18, "bold"), bd=1, width=4,
                             state=tk.DISABLED, textvariable=entry_var)
            entry.grid(row=i, column=1)

            self.dessert_vars.append(var)
            self.dessert_entries.append(entry)

    def build_cost_panel(self):
        # Cost panel UI placeholders can be built here
        pass

    def build_calculator(self):
        # Calculator UI and logic placeholders can be added here
        pass

    def build_ticket_area(self):
        # Ticket display area placeholder
        pass

    def build_buttons(self):
        # Button setup like Total, Save, Reset
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = RestaurantBillingApp(root)
    root.mainloop()
