from collections import Counter 
from collections import defaultdict
from collections import namedtuple

count = Counter([1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,3,4])

print("\n### COUNTER ###\n")
print(count.most_common())
print(count.most_common(1))
print(list(count))

print("\n### DEFAULTDICT ###\n")
dict = defaultdict(lambda: "nothing")
dict["one"] = "Green"
print(dict["one"])
print(dict["two"])
print(dict)

print("\n### NAMEDTUPLE ###\n")

people = namedtuple("People", ["name", "heigh", "weight"])
paco = people("Paco", 1.78, 89)
print(paco)
print(paco[2])