import os
import time
from os import system
from pathlib import Path



# 1 - Define the route
path = Path(Path.home(),"Documentos", "Cursos_python", "Curso_basico", "Recetas")


def welcome()-> str :
    """
    Displays a menu with options.

    This function continuously prompts the user to select an option from the menu.
    It clears the console at the start and ensures that the input is valid before returning.

    Returns:
        str: The number corresponding to the menu option chosen by the user.
    """

    # cls and clear are terminal/command prompt commands used to clear the screen.
    system('clear')
    
    #menu
    choice = 'x'
    while not choice.isnumeric():
        print("Choose an option from the menu")
        print("""
            1- Read recipe
            2- Create recipe
            3- Create new Category
            4- Delete recipe
            5- Delete Category
            6- exit
            """)
         
        choice = input()
        return choice



    

    
def show_category(path:str) -> list:
    """
    Displays a list of categories based on the specified directory.

    This function iterates through the directory where the category folders are located,
    checks each folder, and appends their names to a list that will be returned.

    Args:
        path (str): The path to the directory containing the category folders.

    Returns:
        list: A list of category folder paths.

    """

    print("Categories:")
    path_categories = Path(path)
    list_categories = []
    counter = 1

    for folder in path_categories.iterdir():
        folder_str = str(folder.name) # casting to string
        print(f"[{counter}] - {folder_str}")
        list_categories.append(folder)
        counter += 1

    return list_categories

def choose_category(categories:list) :
    """
    Prompts the user to choose a category from a list of available categories.

    This function validates user input to ensure they select a valid option from the 
    provided categories. It keeps prompting until a valid selection is made.

    Args:
        categories (list): A list of categories to choose from.

    Returns:
        str: The selected category from the list.
    """
    
    choice = "x"
    while not choice.isnumeric() or int(choice) not in range(1, len(categories) + 1) :
        choice = input("\n Choose a category: ")
    
    return categories[int(choice) -1 ]

def show_recipe(path:str) -> list:
    """
    Displays a list of recipes located in the specified directory.

    This function iterates through the given directory, identifies recipe folders,
    and prints their names in a numbered list. It also compiles a list of the folder 
    paths, which is returned.

    Args:
        path (str): The path to the directory containing recipe folders.

    Returns:
        list: A list of paths corresponding to the recipe folders.
    """

    print("Recipes:")
    path_recipes = Path(path)
    list_recipes = []
    counter = 1

    for folder in path_recipes.iterdir():
        folder_str = str(folder.name) # casting to string
        print(f"[{counter}] - {folder_str}")
        list_recipes.append(folder)
        counter += 1

    return list_recipes

def choose_recipe(recipes:list) :
    """
    Prompts the user to select a recipe from a list of available recipes.

    This function validates the user's input to ensure it corresponds to a valid
    recipe in the list. It repeatedly asks for input until a valid choice is made.

    Args:
        recipes (list): A list of recipes to choose from.

    Returns:
        Any: The selected recipe from the list.
    """

    choice = "x"
    while not choice.isnumeric() or int(choice) not in range(1, len(recipes) + 1) :
        choice = input("\n Choose a recipe: ")
    
    return recipes[int(choice) -1 ]

def read_recipe(recipe) :
    """
    Reads and displays the content of a recipe file.

    This function uses the `Path.read_text()` method to read the contents of the 
    specified recipe file and prints it to the console.

    Args:
        recipe (Path): The path to the recipe file to be read.
    """

    print( Path.read_text(recipe))

def create_recipe(category_path) : 
    """
    Creates a new recipe file in the specified category directory.

    This function prompts the user for a recipe name and content, then attempts 
    to create the file within the given category path. If a file with the same name 
    already exists, the user is notified and prompted to enter a different name.

    Args:
        category_path (str or Path): The path to the directory where the recipe 
        file will be created.
    """
    
    exist = False
    while not exist :
        print("Write the name of the new recipe: ")
        name = (input() + ".txt")
        content = input("Write the content of the recipe: ")
        new_path = Path(category_path, name)

        if not os.path.exists(new_path) :
            Path.write_text(new_path, content)
            exist = True
        else :
            print("This file already exists")

def create_category(path) : 
    """
    Creates a new category directory within the specified path.

    This function prompts the user for the name of a new category, then attempts to 
    create a directory with that name in the given path. If a directory with the same 
    name already exists, the user is notified and prompted to enter a different name.

    Args:
        path (str or Path): The path to the directory where the new category will be created.
    """
    exist = False
    while not exist :
        print("Write the name of the new category: ")
        name = (input())
        new_path = Path(path, name)

        if not os.path.exists(new_path) :
            Path.mkdir(new_path)
            exist = True
            print(f"The category {name} was created, successfully")
        else :
            print("This Category already exists")

def delete_recipe(deleting_path) :
    """
    Deletes a recipe file at the specified path.

    This function checks if the recipe file exists at the given path. If it does, 
    the file is removed. Otherwise, it notifies the user that the file does not exist.

    Args:
        deleting_path (str or Path): The path to the recipe file to be deleted.
    """
    
    if Path(deleting_path).exists() :
        os.remove(deleting_path)
        print("Recipe deleted")
    else :
        print("This recipe doesn't exists")

def delete_category(deleting_path) :
    """
    Deletes a category directory at the specified path.

    This function checks if the category directory exists at the given path. If it does, 
    the directory is removed. Otherwise, it notifies the user that the directory does not exist.

    Args:
        deleting_path (str or Path): The path to the category directory to be deleted.
    """

    if Path(deleting_path).exists() :
        Path.rmdir(deleting_path)
        print("Recipe deleted")
    else :
        print("This recipe doesn't exists")


program_ended = False

while not program_ended :
    menu = welcome()

    if menu.isnumeric() and (7 > int(menu) > 0) :
        menu = int(menu)
        # 1- Read recipe
        if menu == 1:
            categories = show_category(path)
            chosen_category = choose_category(categories)
            recipes = show_recipe(chosen_category)
            if len(recipes) < 1 :
                print("This category is empty")
            else :
                chosen_recipe = choose_recipe(recipes)
                #read recipe
                read_recipe(chosen_recipe)
            
            #waits 3 seconds
            time.sleep(3)

        # 2- Create recipe
        if menu == 2:
            categories = show_category(path)
            chosen_category = choose_category(categories)

            #create recipe
            create_recipe(chosen_category)

            #waits 3 seconds
            time.sleep(3)

        # 3- Create category
        if menu == 3:
            create_category(path)
        
        # 4- Delete recipe
        if menu == 4:
            categories = show_category(path)
            chosen_category = choose_category(categories)
            recipes = show_recipe(chosen_category)
            chosen_recipe = choose_recipe(recipes)
            delete_recipe(chosen_recipe)

        # 5- Delete category
        if menu == 5:
            categories = show_category(path)
            chosen_category = choose_category(categories)
            delete_category(chosen_category)

        # 6- Exit program
        if menu == 6:
            program_ended = True
            print("Goodby !!!")

            #waits 3 seconds
            time.sleep(3)
            break
    else :
        print("Menu options only go from 1 to 6. Try Again !!")
        #waits 3 seconds
        time.sleep(3)