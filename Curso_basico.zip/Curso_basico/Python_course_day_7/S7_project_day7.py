# Program that simulates transactions on a fictional bank

from os import system
import random
import time


class Person :

    def __init__(self, name, surname):
        self.name = name
        self.surname = surname

class Client(Person) :

    def __init__(self, name:str, surname:str, account_number:str, balance:float):
        super().__init__(name, surname)
        self.account_number = account_number
        self.balance = round(balance, 2)

    def __str__(self):
        return f"""{self.name} {self.surname} 
        is the owner of the account: 
        {self.account_number} 
        and has a balance of: 
        {self.balance}"""
    
    def deposit(self, amount:float) :
        self.balance += amount

    def subtract(self, amount:float) :
        self.balance -= amount

def create_client() -> Client :
    name = str(input("Introduce your name: "))
    surname = str(input("Introduce your surname: "))
    account_number = "ES" + str(random.randint(1000000000,9999999999))
    balance = float(input("Insert the initial balance: "))
    
    client = Client(name, surname, account_number, balance)

    print("Client created !!!")

    time.sleep(2)

    return client

def load_menu() -> str :
    # cls and clear are terminal/command prompt commands used to clear the screen.
    system('clear')
    
    #menu
    choice = 'x'
    while not choice.isnumeric():
        print("Choose an option from the menu")
        print("""
            1- Client info
            2- Deposit
            3- Subtract
            4- exit
            """)
         
        choice = input()
        return choice
    
def print_client_info(client:Client) :
    print(client.__str__())

def get_info_deposit() ->float :
    amount = float(input("How much do you want to deposit? \n"))
    return amount

def deposit(client:Client, amount:float) :
    client.deposit(amount)
    print(f"""{client.name} {client.surname}
    made a deposit of {amount} €
    the current balance is now: {client.balance} €
    """)

def get_info_subtract() -> float :
    amount = float(input("How much do you want to subtract? \n"))
    return amount

def subtract(client:Client, amount:float) :
    #Check if the client has enough money in the acount
    if client.balance > amount :
        client.subtract(amount)
        print(f"""{client.name} {client.surname}
        made a subtraction of {amount} €
        the current balance is now: {client.balance} €
        """)
    else :
        print("You don't have enough money in the account")

def start() :
    # cls and clear are terminal/command prompt commands used to clear the screen.
    system('clear')

    program_ended = False
    client = create_client()

    while program_ended == False :
        menu = load_menu()

        if menu.isnumeric() and (5  > int(menu) > 0) : 
            menu = int(menu)

            if menu == 1:
                print_client_info(client)
                time.sleep(5)
            
            if menu == 2:
                amount = get_info_deposit()
                deposit(client, amount)
                time.sleep(2)

            if menu == 3:
                amount = get_info_subtract()
                subtract(client, amount)
                time.sleep(2)

            if menu == 4:
                program_ended = True
                print("Goodby!!!")
                time.sleep(2)

        else :
            print("Menu options are only from 1 to 4. Tray again!! ")
            time.sleep(2)

start()