"""
    Console-based store simulation program.
    Allows the user to select witch area of the store they want to get a waiting ticket for
    - Pharmacy
    - Cosmetics
    - Holistic
    Includes basic error handling and user input validation.
"""

from os import system
import random
import time
import store_numbers

def ask():
    system('clear')
    print("Welcome to the store")

    while True:
        print("""
              [P] - Pharmacy
              [C] - Cosmetics
              [H] - Holistic
              """)
        
        try:
            choice = input("Select a letter: ").upper()
            ["P","C","H"].index(choice)
        except ValueError:
            print("That's not a valid answer")
        else:
            break
    
    store_numbers.decorator(choice)

def start():
    system('clear')
    while True:
        ask()
        try:
            other_turn = input("Do you want to take another turn?  [S] [N]").upper
            ["S", "N"].index(other_turn)
        except ValueError:
            print("Not a valid option")
        else:
            if other_turn == "N":
                print("Thanks for visiting our store")
                break

start()