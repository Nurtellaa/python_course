def num_pharmacy():
    for num in range(1, 1000):
        yield f"P - {num}"

def num_cosmetic():
    for num in range(1, 1000):
        yield f"C - {num}"

def num_holistic():
    for num in range(1, 1000):
        yield f"H - {num}"

p = num_pharmacy()
c = num_cosmetic()
h = num_holistic()

def decorator(choice):
    print("\n" + "*" * 23)
    print("Your number is: ")
    if choice == "P":
        print(next(p))
    elif choice == "C":
        print(next(c))
    elif choice == "H":
        print(next(h))
    else:
        print("Invalid option")
    print("Wait until you are attended")
    print("\n" + "*" * 23)