def change_text(word: str) -> str:
    """
    Converts a string to uppercase.

    Args:
        word (str): The input string.

    Returns:
        str: The string converted to uppercase.
    """
    return word.upper()

import unittest

class TestTextChanger(unittest.TestCase):

    def test_uppercase(self):
        word = 'hola'
        result = change_text(word)
        self.assertEqual(result, "HOLA")

if __name__ == '__main__':
    unittest.main()
