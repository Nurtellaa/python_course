import speech_recognition as sr
import pywhatkit
import yfinance as yf
import pyjokes
import webbrowser
import datetime
import wikipedia
from gtts import gTTS
import playsound
import os

# Speak using gTTS with English voice
def speak(message):
    try:
        tts = gTTS(text=message, lang='en')
        tts.save("temp.mp3")
        playsound.playsound("temp.mp3")
        os.remove("temp.mp3")
    except Exception as e:
        print("Error speaking:", e)

# Listen through the mic and return audio as text
def transform_audio_to_text():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        recognizer.pause_threshold = 0.8
        print("You can speak now...")

        audio = recognizer.listen(source)

        try:
            command = recognizer.recognize_google(audio, language="en-US")
            print("You said:", command)
            return command
        except sr.UnknownValueError:
            print("Oops, I didn't understand.")
            return "I'm still waiting"
        except sr.RequestError:
            print("Oops, service is down.")
            return "I'm still waiting"
        except Exception as e:
            print("Unexpected error:", e)
            return "I'm still waiting"

# Tell the current day
def tell_day():
    today = datetime.date.today()
    day_number = today.weekday()

    days = {
        0: 'Monday',
        1: 'Tuesday',
        2: 'Wednesday',
        3: 'Thursday',
        4: 'Friday',
        5: 'Saturday',
        6: 'Sunday'
    }

    speak(f"Today is {days[day_number]}")

# Tell the current time
def tell_time():
    now = datetime.datetime.now()
    time_message = f"It is {now.hour} hours, {now.minute} minutes and {now.second} seconds"
    print(time_message)
    speak(time_message)

# Initial greeting based on time of day
def initial_greeting():
    now = datetime.datetime.now()
    if now.hour < 6 or now.hour > 20:
        moment = "Good evening"
    elif 6 <= now.hour < 13:
        moment = "Good morning"
    else:
        moment = "Good afternoon"

    speak(f"{moment}, I am Helena, your personal assistant. How can I help you?")

# Main assistant function
def handle_commands():
    initial_greeting()
    running = True

    while running:
        command = transform_audio_to_text().lower()

        if 'open youtube' in command:
            speak('Sure, opening YouTube now.')
            webbrowser.open('https://www.youtube.com')
        elif 'open browser' in command:
            speak('Sure, opening your browser.')
            webbrowser.open('https://www.google.com')
        elif 'what day is it' in command:
            tell_day()
        elif 'what time is it' in command:
            tell_time()
        elif 'search on wikipedia' in command:
            speak('Searching on Wikipedia...')
            query = command.replace('search on wikipedia', '').strip()
            wikipedia.set_lang('en')
            try:
                result = wikipedia.summary(query, sentences=1)
                speak("According to Wikipedia:")
                speak(result)
            except:
                speak("Sorry, I couldn't find anything.")
        elif 'search the internet' in command:
            speak('Searching the internet...')
            query = command.replace('search the internet', '')
            pywhatkit.search(query)
            speak("Here is what I found.")
        elif 'play' in command:
            speak('Playing it now...')
            pywhatkit.playonyt(command)
        elif 'joke' in command:
            speak(pyjokes.get_joke(language="en"))
        elif 'stock price of' in command:
            try:
                stock_name = command.split('of')[-1].strip()
                portfolio = {
                    'apple': 'AAPL',
                    'amazon': 'AMZN',
                    'google': 'GOOGL'
                }
                stock_symbol = portfolio.get(stock_name.lower())
                if stock_symbol:
                    stock_data = yf.Ticker(stock_symbol)
                    current_price = stock_data.info['regularMarketPrice']
                    speak(f"The current price of {stock_name} is {current_price} dollars.")
                else:
                    speak("Sorry, I couldn't find that company.")
            except:
                speak("Something went wrong while fetching the stock data.")
        elif 'goodbye' in command or 'bye' in command:
            speak("Goodbye! Let me know if you need anything else.")
            running = False

# Start the assistant
handle_commands()
