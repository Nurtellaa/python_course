import random
import time
import pygame
import math
from pygame import mixer

pygame.init()

#ASSETS LOCATIONS
img_path = str("Python_course_day_10/img/")
sounds_path = str("Python_course_day_10/sounds/")

icon_path = img_path + "alien.png"
player_path = img_path + "ship.png"
enemy_path = img_path + "enemy.png"
background_path = img_path + "background.jpg"
bullet_path = img_path + "bullet.png"

background_music = sounds_path + "background_music.mp3"
shooting_sound = sounds_path + "shoot.wav"
enemy_dying_sound = sounds_path + "enemy_dying.wav"
player_dying_sound = sounds_path + "player_dying.wav"

#Screen
screen = pygame.display.set_mode((800, 600))
background = pygame.image.load(background_path)

#Title
pygame.display.set_caption("Space Invasion")

#icon
icon = pygame.image.load(icon_path)
pygame.display.set_icon(icon)

#Music 
mixer.music.load(background_music)
mixer.music.set_volume(0.5)
mixer.music.play(-1)

#Points
points = 0
font = pygame.font.Font("freesansbold.ttf", 32)
text_x = 600
text_y = 10

#show points
def show_points(x,y):
    text = font.render(f"Points: {points}", True, (255,255,255))
    screen.blit(text, (x,y))

#GAME OVER TEXT
font_gameover = pygame.font.Font("freesansbold.ttf", 70)
def gameover_text():
    text_gameover = font_gameover.render("GAME OVER", True, (255,255,255))
    screen.blit(text_gameover, (190, 250))

#Moving constants
VELOCITY = 0.6
POSITIVE_X = VELOCITY
POSITIVE_Y = VELOCITY
NEGATIVE_X = -VELOCITY
NEGATIVE_Y = -VELOCITY


#Player
img_player = pygame.image.load(player_path)
player_x = 336
player_y = 450
player_moving_x = 0
player_moving_y = 0

def player(x, y):
    screen.blit(img_player, (x,y))

#Enemy
img_enemy = []
enemy_x = []
enemy_y = []
enemy_moving_x = []
enemy_moving_y = []
enemy_amount = 10
increment = 1

enemy_in_same_position = True

occupied_positions = []

for e in range(enemy_amount):
    img_enemy.append(pygame.image.load(enemy_path))
    
    while True:
        x = random.randrange(0, 700, 2)
        y = random.randrange(0, 280, 70)

        # Ensure no other enemy is too close
        too_close = False
        for ox, oy in occupied_positions:
            if abs(x - ox) < 60 and abs(y - oy) < 60:
                too_close = True
                break

        if not too_close:
            occupied_positions.append((x, y))
            enemy_x.append(x)
            enemy_y.append(y)
            break

    enemy_moving_x.append(POSITIVE_X)
    enemy_moving_y.append(70)

def enemy(x,y, ene):
    screen.blit(img_enemy[ene],(x,y))


#Bullet
img_bullet = pygame.image.load(bullet_path)
bullet_x = 0
bullet_y = 500
bullet_moving_x = 0
bullet_moving_y = 5
bullet_visible = False

def shoot_bullet(x, y):
    global bullet_visible 
    bullet_visible = True
    screen.blit(img_bullet, (x + 52, y + 16))


#Collision detect
def collision(x1, y1, x2, y2):
    distance = math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2))
    if distance < 50:
        return True
    else: 
        return False

#game loop
running = True
while running:

    #Image background
    screen.blit(background,(0,0))
    # Draw end line AFTER the background
    pygame.draw.line(screen, (179,0,0), [0, 410], [800, 410], 5)

    #EVENT MANAGER
    for event in pygame.event.get():
        # QUIT EVENT
        if event.type == pygame.QUIT:
            running = False
        
        # PRESSED KEYS
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player_moving_x = NEGATIVE_X * 4
            if event.key == pygame.K_RIGHT:
                player_moving_x = POSITIVE_X * 4
            if event.key == pygame.K_SPACE:
                sound_bullet = mixer.Sound(shooting_sound)
                sound_bullet.set_volume(0.2)
                sound_bullet.play()
                if not bullet_visible:
                    bullet_x = player_x
                    shoot_bullet(bullet_x, bullet_y)

        # UNPRESSED KEYS
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key ==pygame.K_RIGHT:
                player_moving_x = 0

    #RENDER PLAYER
    player_x += player_moving_x
    #keep player inside screen
    if player_x <= 0:
        player_x = 0
    elif player_x >= 672:
        player_x = 672
    
    #bullet
    if bullet_y <= -60:
        bullet_y = 500
        bullet_visible = False

    if bullet_visible:
        shoot_bullet(bullet_x, bullet_y)
        bullet_y -= bullet_moving_y

    player(player_x, player_y)

    # Rebuild occupied_positions each frame based on current enemy positions
    occupied_positions = []
    for ex, ey in zip(enemy_x, enemy_y):
        occupied_positions.append((ex, ey))

    # RENDER ENEMY
    for e in range(enemy_amount):

        if enemy_y[e] > 410:
            for k in range(enemy_amount):
                enemy_y[k] = 1000
            gameover_text()
            break

        # Create difficulty by increments
        increment = 1  # default
        if points > 80:
            increment = 5
        elif points > 60:
            increment = 3
        elif points > 20:
            increment = 2

        enemy_x[e] += enemy_moving_x[e]

        # Enemy hits screen borders
        if enemy_x[e] <= 0:
            enemy_moving_x[e] = POSITIVE_X * increment
            enemy_y[e] += enemy_moving_y[e]
        elif enemy_x[e] >= 738:
            enemy_moving_x[e] = NEGATIVE_X * increment
            enemy_y[e] += enemy_moving_y[e]

        # COLLISION MANAGER
        col_enemy_bullet = collision(enemy_x[e], enemy_y[e], bullet_x, bullet_y)

        if col_enemy_bullet:
            collision_sound = mixer.Sound(enemy_dying_sound)
            collision_sound.set_volume(0.5)
            collision_sound.play()

            bullet_y = 500
            bullet_visible = False
            points += 1

            # Remove old position from occupied_positions
            old_pos = (enemy_x[e], enemy_y[e])
            if old_pos in occupied_positions:
                occupied_positions.remove(old_pos)

            # Respawn enemy in non-overlapping position
            while True:
                x = random.randrange(0, 700, 2)
                y = random.randrange(0, 280, 70)

                too_close = False
                for ox, oy in occupied_positions:
                    if abs(x - ox) < 60 and abs(y - oy) < 60:
                        too_close = True
                        break

                if not too_close:
                    occupied_positions.append((x, y))
                    enemy_x[e] = x
                    enemy_y[e] = y
                    break

        enemy(enemy_x[e], enemy_y[e], e)


    #Show points
    show_points(text_x, text_y)
    
    #UPDATE
    pygame.display.update()
